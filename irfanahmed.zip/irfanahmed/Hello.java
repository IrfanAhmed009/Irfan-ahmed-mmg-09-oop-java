public class Hello {
    public static void main(String[] args) {
        System.out.println("//////////////////////");
        System.out.println("     Student Point    ");
        System.out.println("//////////////////////");
        System.out.println(" Lab      Bonus    Total");
        System.out.println(" -----------------------");
        System.out.println(" 42         7        50");
        System.out.println(" 50         8        58");
        System.out.println(" 39        10        49");
    }
}

public class MathExpression {
    public static void main(String[] args) {
        int result = (10 + 5) * (4 - 6) / 4;
        System.out.println("Result of the expression (10+5)*(4-6)/4: " + result);
    }
}
